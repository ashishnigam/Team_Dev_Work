card.io SDK for Android
-----------------------

Thanks for downloading the card.io SDK for Android! Please don't hesitate to contact us at support@card.io with any questions. We'd love to help you get started.

You can view complete integration instructions and sample code online:
http://www.card.io/integrate/android

Javadoc is available at:
http://www.card.io/resources/javadoc/index.html

Instructions for upgrading from SDK 1.0 to SDK 2.0 can be found in the included upgrading.txt file.

Thanks again!
The card.io team
support@card.io
