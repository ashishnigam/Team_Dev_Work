Summary
-------

card.io's Android SDK uses code from the following libraries (with gratitude!):

  * Willow Garage's [OpenCV](http://opencv.willowgarage.com/wiki/)
  * Loopj's [Android Asnyc HTTP](http://loopj.com/android-async-http/)


Full licenses
-------------

Willow Garage's OpenCV, BSD license:

    Actual license text not provided -- [the OpenCV website](http://opencv.willowgarage.com/wiki/) says "OpenCV is released under a BSD license, it is free for both academic and commercial use.", with links to http://opensource.org/licenses/bsd-license.php and http://en.wikipedia.org/wiki/BSD_licenses


Loopj's Android Async HTTP, Apache License 2.0:

    Actual license text not provided -- [The loopj website](http://loopj.com/android-async-http/) states "The Android Asynchronous Http Client is released under the Android-friendly Apache License, Version 2.0. Read the full license here: http://www.apache.org/licenses/LICENSE-2.0"