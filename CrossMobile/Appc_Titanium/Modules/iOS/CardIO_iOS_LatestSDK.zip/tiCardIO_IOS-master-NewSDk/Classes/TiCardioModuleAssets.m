/**
 * This is a generated file. Do not edit or your changes will be lost
 */
#import "TiCardioModuleAssets.h"

extern NSData* filterDataInRange(NSData* thedata, NSRange range);

@implementation TiCardioModuleAssets

- (NSData*) moduleAsset
{
	return nil;
}

@end
