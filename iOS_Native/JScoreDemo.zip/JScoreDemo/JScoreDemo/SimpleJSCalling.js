(function (){
    var val = 10;
    return val;
 })();


 var PrintHello = function(args){
    
    var result = "Hello! " + args;
    return result;
}