//
//  ANAppDelegate.h
//  JScoreDemo
//
//  Created by Ashish Nigam on 23/05/14.
//  Copyright (c) 2014 Self. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ANAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
