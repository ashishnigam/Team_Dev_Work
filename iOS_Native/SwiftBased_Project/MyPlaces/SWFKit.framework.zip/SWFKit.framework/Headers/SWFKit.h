//
//  SWFKit.h
//  SWFKit
//
//  Created by Ashish Nigam on 20/01/16.
//  Copyright © 2016 Ashish. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for SWFKit.
FOUNDATION_EXPORT double SWFKitVersionNumber;

//! Project version string for SWFKit.
FOUNDATION_EXPORT const unsigned char SWFKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SWFKit/PublicHeader.h>

#import <SWFKit/SFSineWave.h>