//
//  SFSineWave.h
//  SWFKit
//
//  Created by Ashish Nigam on 20/01/16.
//  Copyright © 2016 Ashish. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SFSineWave : NSObject
-(void)printCurrentWave;
@end
