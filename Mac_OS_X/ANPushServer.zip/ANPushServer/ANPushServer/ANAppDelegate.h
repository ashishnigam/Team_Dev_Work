//
//  ANAppDelegate.h
//  ANPushServer
//
//  Created by Ashish Nigam on 25/03/14.
//  Copyright (c) 2014 Self. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface ANAppDelegate : NSObject <NSApplicationDelegate>

@property (assign) IBOutlet NSWindow *window;

@end
