//
//  main.m
//  ANPushServer
//
//  Created by Ashish Nigam on 25/03/14.
//  Copyright (c) 2014 Self. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[])
{
    return NSApplicationMain(argc, argv);
}
